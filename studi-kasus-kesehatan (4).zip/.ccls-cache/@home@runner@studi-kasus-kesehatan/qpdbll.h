// #include <iostream>
// #include <stdlib.h>
// using namespace std;

// enum{
// 	FALSE=0,TRUE=-1
// };
// class PriorityQueue	{

// private:
// 	struct Node	{
// 		struct Node *Previous;
// 		int Data;
// 		string nama;
//     string jenis_pasien;
// 		struct Node *Next;
// 	} Current;

// 	struct Node *head;	
// 	struct Node *ptr;	
// 	static int NumOfNodes;

// public:
// 	PriorityQueue(void);
// 	int Maximum(void);
// 	int Minimum(void);
// 	void Insert(int);
// 	int Delete(int);
// 	void Display(void);
// 	int Search (int);
// 	~PriorityQueue(void);
// };

// int PriorityQueue::NumOfNodes = 0;

// PriorityQueue::PriorityQueue(void){}

// int PriorityQueue::Maximum(void){
// 	if (NumOfNodes==0) return FALSE;
// 	int Temp;
// 	ptr=head;
// 	Temp=ptr->Data;

// 	while(ptr->Next!=NULL){
// 		if(ptr->Data>Temp)
// 			Temp=ptr->Data;
// 		ptr=ptr->Next;
// 	}
// 	if(ptr->Next==NULL && ptr->Data>Temp)
// 		Temp=ptr->Data;
// 	ptr=head;
// 	return(Temp);
// }

// int PriorityQueue::Minimum(void){
// 	int Temp;
// 	ptr=head;
// 	Temp=ptr->Data;

// 	while(ptr->Next!=NULL){
// 		if(ptr->Data<Temp)
// 			Temp=ptr->Data;
// 		ptr=ptr->Next;
// 	}
// 	if(ptr->Next==NULL && ptr->Data<Temp)
// 		Temp=ptr->Data;
// 	ptr=head;
// 	return(Temp);
// }

// void PriorityQueue::Insert(int DT){
// 	struct Node *node = new Node;
// 	node->Data=DT;
// 	if (DT==1) {
// 		cout << "--- Pasien Gawat Darurat ---" << endl;
// 	}
// 	else if (DT==2) {
// 		cout << "--- Pasien umum ---" << endl;
// 	}
// 	cout << "Masukkan Nama Pasien : ";
//   getline(cin,node->nama);
// 	cout << "Masukkan Jenis Pasien : "; 
//   getline(cin,node->jenis_pasien);
// 	cout << endl;
// 	if (NumOfNodes==0) {
// 		cout << "Test dipertama" << endl;
// 		Current.Previous=NULL;
// 		Current.Data=DT;
// 		Current.nama=node->nama;
// 		Current.jenis_pasien=node->jenis_pasien;
// 		Current.Next=NULL;
// 		head=&Current;
// 		ptr=head;
// 		head = ptr;
// 		NumOfNodes++;
// 		return;
// 	}
  
// 	if(node->Data>Maximum())
// 	{
// 		node->Next=NULL;
// 		if (NumOfNodes==1) {
// 			node->Previous=ptr;
// 			ptr->Next=node;
// 			ptr = head;
// 		}
// 		else {
// 			while (ptr->Next!=NULL) {
// 				ptr = ptr->Next;
// 			}
// 			node->Next = ptr->Next;
// 			node->Previous = ptr;
// 			if (ptr->Next!=NULL) ptr->Next->Previous = node;
// 			ptr->Next = node;
// 			ptr = head;
// 		}

		
// 	}
// 	else if(node->Data<Maximum()){
// 		cout << "Masuk ke data input < max" << endl;
// 		while (ptr->Next!=NULL) {
// 			if (ptr->Data<=node->Data) {
// 				cout << "if Sekarang di ptr Max = " << ptr->Data << endl;
// 				ptr = ptr->Next;
// 			}
// 			else {
// 				cout << "Else Sekarang di ptr Max = " << ptr->Data << endl;
// 				break;
// 			}
// 		}
// 		node->Next = ptr;
// 		node->Previous = ptr->Previous;
// 		if (ptr->Previous!=NULL) ptr->Previous->Next = node;
// 		ptr->Previous = node;
// 		ptr = head;

// 	}
// 	else {
// 		cout << "Masuk ke sama" << endl;
// 		if (NumOfNodes!=1) {
// 			while (ptr->Next!=NULL) {
// 				if (ptr->Data<=node->Data) {
// 					ptr = ptr->Next;
// 				}
// 				else {
// 					break;
// 				}
// 			}
// 			node->Next = ptr->Next;
// 			node->Previous = ptr;
// 			if (ptr->Next!=NULL) ptr->Next->Previous = node;
// 			ptr->Next = node;
// 			ptr = head;

// 		}
// 		else {
// 			node->Next = NULL;
// 			node->Previous = ptr;
// 			ptr->Next = node;
// 			ptr = head;
// 		}
// 	}
// 	NumOfNodes++;
// }

// int PriorityQueue::Delete(int DataDel){
// 	cout << "Test masuk" << "dan " << NumOfNodes << endl;
// 	struct Node *mynode;
// 	struct Node *temp;

// 	if (NumOfNodes==1) {
// 		cout << "Test diperiksa ga nih" << endl;
// 		head = NULL;
// 		ptr = NULL;	
// 		NumOfNodes--;	
// 		return 0;
// 	}

// 	ptr=head;

// 	while (ptr->Next!=NULL) {
// 		ptr = ptr->Next;
// 	}
// 	temp = ptr;
// 	ptr = ptr->Previous;
// 	ptr->Next = NULL;
// 	delete temp;
// 	NumOfNodes--;

// 	ptr = head;
// 	return 0;
// }

// int PriorityQueue::Search(int DataSearch){
// 	ptr=head;
// 	while(ptr->Next!=NULL){
// 		if(ptr->Data==DataSearch)
// 			return ptr->Data;
// 		ptr=ptr->Next;
// 	}
// 	if(ptr->Next==NULL && ptr->Data==DataSearch)
// 		return ptr->Data;
// 	return(FALSE);
// }


// void PriorityQueue::Display(void){
// 	if (NumOfNodes==0) {
// 		cout << "\n\e[1;31mAntrian Pasien Kosong\e[0m" << endl;
// 		return;
// 	}
// 	int i = 1;
// 	ptr=head;

// 	system("clear");
// 	cout << "No. Antri      \tNama  \tJenis Pasien " << endl; 
// 	cout << "----------------------------------------------------------------------" << endl;
// 	while(ptr!=NULL)
// 	{
// 		cout << i << "|\t\t         |" << ptr->nama << "|\t\t|" << ptr->jenis_pasien << "|\t\t|";
// 		if (ptr->Data==1) {
// 			cout << "Pasien Gawat Darurat" << endl;
// 		}
// 		else if (ptr->Data==2) {
// 			cout << "Pasien Umum" << endl;
// 		}
// 		ptr=ptr->Next;
// 		i++;
// 	}
// 	ptr = head;
// 	cout << endl;
// }

// PriorityQueue::~PriorityQueue(void){
// 	struct Node *temp;                      
// 	while(head->Next!=NULL){
// 		temp=head->Next;
// 		head=temp;
// 	}
// 	if(head->Next==NULL)
// 		delete head;
// }
// int main() {
// 	system("clear");
// 	PriorityQueue PQ;
// 	int choice;
// 	int DT;

// 	while(1)
// 	{
// 		cout<<"|-------------------------------------------|"<<endl;
// 		cout<<"|            UGD RUMAH SAKIT TAVIZI         |"<<endl;
// 		cout<<"|-------------------------------------------|"<<endl;
// 		cout<<"1. Registrasi Pasien"<<endl;
// 		cout<<"2. Tampilkan Antrian Pasien"<<endl;
// 		cout<<"3. Mulai Tindakan"<<endl;
// 		cout<<"4. Exit"<<endl;
//     cout<<"Masukan Pilihan : ";
// 		cin>>choice;
// 		switch(choice)
// 		{
// 		case 1:
// 			system("clear");
// 			cout<<"Pilih Kategori Pasien : "<<endl;
// 			cout<<"1. Pasien Gawat Darurat"<<endl;
// 			cout<<"2. Pasien Umum"<<endl;
// 			cout<<"3. Mulai Tindakan"<<endl;
// 		  cout<<"4. Exit"<<endl;
//       cout<<"---------------------------"<<endl;
//       cout<<"Masukan pilihan : ";
// 			cin>>DT; getchar();
// 			PQ.Insert(DT);
// 			break;
// 		case 2:
// 			PQ.Display();
// 			break;
// 		case 3:
// 			if (PQ.Maximum()==FALSE) {
// 				cout << "Antrian pasien kosong" << endl;
// 			}
// 			else {
// 				PQ.Delete(PQ.Maximum());
//         cout << "Pendaftaran Pasien Selesai "<<endl;
// 				cout << "Pasien Mulai Dievakuasi" << endl;
// 			}
//       break;
// 		case 4:
// 			exit(4);
//      cout<<"Terimakasih"<<endl;
// 		default:
// 			cout<<"Tidak dapat memproses pendaftaran"<<endl;
// 		}
// 	}
// 	return 0;
// }