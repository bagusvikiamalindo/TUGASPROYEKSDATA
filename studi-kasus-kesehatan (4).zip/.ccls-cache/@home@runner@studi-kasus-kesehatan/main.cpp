#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string.h>
#include"class.h"
#include"classkamar.h"
#include"Alat.h"
#include"covid.h"
#include"ktp.h"
#include"filetxt.h"
#include"linklistsingle.h"
#include"linklistdouble.h"
#include"095.h"
#include"113.h"
#include"070.h"
#include"Output.h"
#include"tokoobat.h"
#include"konsultasi.h"
#include"pengkajian.h"
#include"PriorityQueue.h"
#include"classvaksin.h"
#include"tree.h"
#include"treeavl.h"
#include "sortingobat.h""
//#define MAX 100

int main() {
  int pilmn;
  Apotek x;
  Kamar k;
  Covid b;
  classvaksin qu;
  PriorityQueue g;
  icu icu;
  skin skin;
  do{
  cout<<"=========================================="<<endl;
  cout<<"|         MENU RUMAH SAKIT TAVIZI         |"<<endl;
  cout<<"=========================================="<<endl;
  cout<<"Pilihan menu : "<<endl;
  cout<<"1. Menu Rumah Sakit "<<endl;
  cout<<"2. Menu Tambahan "<<endl;
  cout<<"3. Menu Tes Covid "<<endl;
  cout<<"4. Menu Vaksin Covid"<<endl;
  cout<<"5. Menu UGD"<<endl;
  cout<<"6. Menu ICU"<<endl;
  cout<<"7. Skin & Aesthetic Clinic"<<endl;
  cout<<"=========================================="<<endl;
  cout<<"Masukkan pilihan : ";
  cin>>pilmn;
  if(pilmn==1){
    cout<<endl;
    x.input();
    x.filetxt();
    } 
    else if(pilmn==2){
    cout<<endl;
    k.menuu();
    } 
    else if(pilmn==3){
    cout<<endl;
    b.tescovid();
    } 
    else if(pilmn==4){
    cout<<endl;
    qu.vaksi();
    }
    else if(pilmn==5){
    cout<<endl;
    g.menugd();
    }
    else if(pilmn==6){
    cout<<endl;
    icu.menu();
    }
    else if(pilmn==7){
    cout<<endl;
    skin.menu();
    }
  
   else {
    cout<<"============================================="<<endl;
    cout<<"|                Terima kasih               |"<<endl;
    cout<<"============================================="<<endl;
    //break;
  }
  }while(pilmn!=7);
  return 0;
}