#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string.h>
#include <fstream>

using namespace std;

class skin{
  public:
    void viewPostOrder(struct treeavl *roott);
    void viewInOrder(struct treeavl *roott);
    void viewPreOrder(struct treeavl *roott);
    void cetakPostOrder(struct treeavl *roott);
    void cetakInOrder(struct treeavl *roott);
    void cetakPreOrder(struct treeavl *roott);
    void statusAVL(struct treeavl *roott);
    void menu();
    void paketskin();
  private:
    int nik, harga, pilpaket;
    string nama, paket, kembali;
};

struct treeavl{
	int nik;
  string nama, paket;
  int height;
	treeavl *kiri;
	treeavl *kanan;
} *roott = NULL;

int height(struct treeavl *N){
	if (N == NULL)
		return 0;
	return N->height;
}

int max(int a, int b){
	return (a > b)? a : b;
}

struct treeavl* newtreeavl(int nik, string nama, string paket){
	struct treeavl* node7 = (struct treeavl*)malloc(sizeof(struct treeavl));
	node7->nik = nik;
  node7->nama = nama;   
  node7->paket = paket;   
	node7->kiri = NULL;
	node7->kanan = NULL;
	node7->height = 1;
	return(node7);
}

struct treeavl *rightRotate(struct treeavl *y){
	struct treeavl *x = y->kiri;
	struct treeavl *T2 = x->kanan;

	x->kanan = y;
	y->kiri = T2;

	y->height = max(height(y->kiri), height(y->kanan))+1;
	x->height = max(height(x->kiri), height(x->kanan))+1;

	return x;
}

struct treeavl *leftRotate(struct treeavl *x){
	struct treeavl *y = x->kanan;
	struct treeavl *T2 = y->kiri;

	y->kiri = x;
	x->kanan = T2;

	x->height = max(height(x->kiri), height(x->kanan))+1;
	y->height = max(height(y->kiri), height(y->kanan))+1;

	return y;
}

int getBalance(struct treeavl *N){
	if (N == NULL)
		return 0;
	return height(N->kiri) - height(N->kanan);
}

struct treeavl* insertt(struct treeavl* node7, int nik, string nama, string paket){
	if (node7 == NULL){
		return(newtreeavl(nik, nama, paket));
	}
	if (nik < node7->nik){
		node7->kiri = insertt(node7->kiri, nik, nama, paket);
	}
  else if (nik > node7->nik){
		node7->kanan = insertt(node7->kanan, nik, nama, paket);
	}
  else{
		return node7;
  }
	node7->height = 1 + max(height(node7->kiri), height(node7->kanan));

	int balance = getBalance(node7);

	if (balance > 1 && nik < node7->kiri->nik){
		return rightRotate(node7);
	}
	if (balance < -1 && nik > node7->kanan->nik){
		return leftRotate(node7);
	}
	if (balance > 1 && nik > node7->kiri->nik){
		node7->kiri = leftRotate(node7->kiri);
		return rightRotate(node7);
	}
	if (balance < -1 && nik < node7->kanan->nik){
		node7->kanan = rightRotate(node7->kanan);
		return leftRotate(node7);
	}
	return node7;
}

struct treeavl * minValuetreeavl(struct treeavl* node7){
  struct treeavl* currentt = node7;
  while (currentt->kiri != NULL)
    currentt = currentt->kiri;
  return currentt;
}

void skin::viewPreOrder(struct treeavl *roott){
	if(roott != NULL){
    cout << endl;
		cout << " NIK Anda    : " << roott->nik << endl;
		cout << " Nama Anda   : " << roott->nama << endl;  
		skin::viewPreOrder(roott->kiri);
		skin::viewPreOrder(roott->kanan);
	}
}

void skin::viewInOrder(struct treeavl *roott){
	if(roott != NULL){
		skin::viewInOrder(roott->kiri);
		cout << endl;
		cout << " NIK Anda   : " << roott->nik << endl;
		cout << " Nama Anda  : " << roott->nama << endl; 
		skin::viewInOrder(roott->kanan);
	}
}

void skin::viewPostOrder(struct treeavl *roott){
	if(roott != NULL){
		skin::viewPostOrder(roott->kiri);
		skin::viewPostOrder(roott->kanan);
		cout << endl;
		cout << " NIK Anda  : " << roott->nik << endl;
		cout << " Nama Anda : " << roott->nama << endl;  
	}
}

void skin::cetakPreOrder(struct treeavl *roott){
	if(roott != NULL){
    cout << endl;
    cout << "==============================================================" << endl;
	  cout << "            SKIN & AESTHETIC CLINIC" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Anda        : " << roott->nik << endl;
    cout << " Nama Anda       : " << roott->nama << endl;
    cout << " Paket           : " << roott->paket << endl;
	  cout << "==============================================================" << endl;  

    ofstream skintxt("dataskin.txt", ios::app);
    
    skintxt << "==============================================================" << endl;
	  skintxt << "            SKIN & AESTHETIC CLINIC" << endl;
	  skintxt << "--------------------------------------------------------------" << endl;
    skintxt << " NIK Anda        : " << roott->nik << endl;
    skintxt << " Nama Anda       : " << roott->nama << endl;
    skintxt << " Paket           : " << roott->paket << endl;
	  skintxt << "==============================================================" << endl;
	  skintxt << endl;
		skin::cetakPreOrder(roott->kiri);
		skin::cetakPreOrder(roott->kanan);
	}
}

void skin::cetakInOrder(struct treeavl *roott){
	if(roott != NULL){
		skin::cetakInOrder(roott->kiri);
		cout << endl;
    cout << endl;
    cout << "==============================================================" << endl;
	  cout << "            SKIN & AESTHETIC CLINIC" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Anda        : " << roott->nik << endl;
    cout << " Nama Anda       : " << roott->nama << endl;
    cout << " Paket           : " << roott->paket << endl;
	  cout << "==============================================================" << endl;   
    
    ofstream skintxt("dataskin.txt", ios::app);
    
    skintxt << "==============================================================" << endl;
	  skintxt << "            SKIN & AESTHETIC CLINIC" << endl;
	  skintxt << "--------------------------------------------------------------" << endl;
    skintxt << " NIK Anda        : " << roott->nik << endl;
    skintxt << " Nama Anda       : " << roott->nama << endl;
    skintxt << " Paket           : " << roott->paket << endl;
	  skintxt << "==============================================================" << endl;
	  skintxt << endl;
		skin::cetakInOrder(roott->kanan);
	}
}

void skin::cetakPostOrder(struct treeavl *roott){
	if(roott != NULL){
		skin::cetakPostOrder(roott->kiri);
		skin::cetakPostOrder(roott->kanan);
		cout << endl;
    cout << "==============================================================" << endl;
	  cout << "            SKIN & AESTHETIC CLINIC" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Anda        : " << roott->nik << endl;
    cout << " Nama Anda       : " << roott->nama << endl;
    cout << " Paket           : " << roott->paket << endl;
	  cout << "==============================================================" << endl;
    
    ofstream skintxt("dataskin.txt", ios::app);
    
    skintxt << "==============================================================" << endl;
	  skintxt << "            SKIN & AESTHETIC CLINIC" << endl;
	  skintxt << "--------------------------------------------------------------" << endl;
    skintxt << " NIK Anda        : " << roott->nik << endl;
    skintxt << " Nama Anda       : " << roott->nama << endl;
    skintxt << " Paket           : " << roott->paket << endl;
	  skintxt << "==============================================================" << endl;
	  skintxt << endl;
	}
}

void skin::statusAVL(struct treeavl *roott){
	if(roott != NULL){
   	cout << endl;
		cout << "------------- DATA PASIEN SKIN & AESTHETIC BERHASIL --------------" << endl;
  } 
  else {
    cout << endl;
		cout << " Data Pohon Setimbang Kosong " << endl;
  }
}

void skin::menu(){
  int k;
  do { 
    cout<<"1. Tambah data "<<endl;
    cout<<"2. Lihat preorder "<<endl;
    cout<<"3. Lihat inorder "<<endl;
    cout<<"4. Lihat postorder "<<endl;
    cout<<"5. Cetak secara preorder "<<endl;
    cout<<"6. Cetak secara inorder "<<endl;
    cout<<"7. Cetak secara postorder "<<endl;
    cout<<"Masukkan : ";
    cin>>k;
    switch (k){
    case 1:
            skin::paketskin();
            cout << endl;
          	cout << " NIK Pasien  : ";
          	cin >> nik;
            cin.ignore(1);
          	cout << " Nama Pasien : ";
          	getline(cin, nama);
            roott = insertt(roott, nik, nama, paket);
            cout << endl;
            break;
          case 2:
            skin::viewInOrder(roott);
            break;
          case 3:
            skin::viewPreOrder(roott);
            
            break;
          case 4:
            skin::viewPostOrder(roott);
            
            break;
          case 5:
            skin::cetakInOrder(roott);
            skin::statusAVL(roott);
            
            break;
          case 6:
            skin::cetakPreOrder(roott);
            skin::statusAVL(roott);
            
            break;
          case 7:
            skin::cetakPostOrder(roott);
            skin::statusAVL(roott);
            
            break;
          default:
            cout << endl << " Maaf, Pilihan Yang Anda Masukkan Salah" << endl;
  				  cout << endl;
            
            break;
        }
      } while (k < 5);
}

void skin::paketskin(){
  cout<<endl;
  cout<<"==========================================================="<<endl;
  cout << "             LAYANAN SKIN & AESTHETIC CLINIC" << endl;
	cout << "--------------------------------------------------------------" << endl;
  cout << "   1. Laser Rejuvenation Therapy                Rp 500.000 " << endl;
  cout << "   2. Laser Collagen Booster                    Rp 650.000 " << endl;
  cout << "   3. Platelet-Rich Plasma (PRP)                Rp 850.000 " << endl;
  cout << "   4. Microneedling Rejuvenation Therapy        Rp 1.000.000 " << endl;
  cout << "   5. Injeksi Botox                             Rp 1.000.000 " << endl;
  cout << "   6. Filler                                    Rp 1.250.000 " << endl;
  cout << "   7. Peeling                                   Rp 800.000 " << endl;
  cout << "   8. Suntik Jerawat                            Rp 600.000 " << endl;
  cout << "   9. Bedah Minor Kulit                         Rp 750.000 " << endl;
  cout << "   10. Laser CO2 dan Elektrokauterisasi         Rp 900.000 " << endl;
  cout << "   11. Cryotherapy                              Rp 900.000 " << endl;
  cout << "==============================================================" << endl;
  cout << " Masukkan Pilihan Menu (1-12) : ";
  cin >> pilpaket;
  if(pilpaket==1){
    paket = "Laser Rejuvenation Therapy";
    harga = 500000;
  }
  else if(pilpaket==2){
    paket = "Laser Collagen Booster";
    harga = 650000;
  }
  else if(pilpaket==3){
    paket = "Platelet-Rich Plasma (PRP)";
    harga = 850000;
  }
  else if(pilpaket==4){
    paket = "Microneedling Rejuvenation Therapy";
    harga = 1000000;
  }
  else if(pilpaket==5){
    paket = "Injeksi Botox";
    harga = 1000000;
  }
  else if(pilpaket==6){
    paket = "Filler";
    harga = 1250000;
  }
  else if(pilpaket==7){
    paket = "Peeling";
    harga = 800000;
  }
  else if(pilpaket==8){
    paket = "Suntik Jerawat";
    harga = 600000;
  }
  else if(pilpaket==9){
    paket = "Bedah Minor Kulit";
    harga = 750000;
  }
  else if(pilpaket==10){
    paket = "Laser CO2 dan Elektrokauterisasi";
    harga = 900000;
  }
  else if(pilpaket==11){
    paket = "Cryotherapy ";
    harga = 900000;
  }
  else {
    cout << endl;
    cout << " Menu Yang Anda Pilih Tidak Tersedia " << endl;
    cout << endl;
    cout << " Ketik 'y' Untuk Kembali : ";
    cin >> kembali;
    skin::paketskin();
  }
}
