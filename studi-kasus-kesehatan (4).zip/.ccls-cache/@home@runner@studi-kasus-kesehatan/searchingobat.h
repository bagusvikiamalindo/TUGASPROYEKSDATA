/* #include <iostream>
#include <string.h>
using namespace std;

struct obt {
	string obat;
    int kode, stok;
};
class Sobat{
	public :
		void output(obt rumah[], int n);
		void cari(obt rumah[], int n);
		void menobat();
	private :
		int n, i;
		string kata;
};

void Sobat::output(obt rumah[], int n) {
   cout<<"List Obat : "<<endl;
 cout<<"-------------------------------------------------"<<endl;
 cout<<"| No | Kode Obat| Nama Obat | Stok Obat"<<endl;
 cout<<"-------------------------------------------------"<<endl;
 for(i=1;i<=n;i++){
  cout<<"| "<<i<<"  |    "<<rumah[i].kode<<"    |    "<<rumah[i].obat<<"   | "<<rumah[i].stok;
      cout<<endl;
 }
   cout<<"-------------------------------------------------"<<endl;
   cout<<endl<<endl;
}

void Sobat::cari(obt rumah[], int n) {
    bool ketemu=false;
    int lokasi=-1;
    cout<<"Silakan masukkan Obat yang ingin dicari : "; cin>>kata;
    for (int i=1;i<=n;i++) {
       if(kata==rumah[i].obat) {
          ketemu=true;
          lokasi=i;
       }
    }
    if (ketemu==true){
       cout<<kata<<" Ditemukan pada Nomor ke- "<<lokasi<<endl;
    }else{
       cout<<"Maaf, nama obat "<<kata<<" tidak tersedia "<<endl;
   }
}
void Sobat::menobat() {
    obt rumah[50];
    cout<<"Searching Obat"<<endl<<endl;
    cout<<"Masukan banyak data : "; cin>>n;
    cout<<endl;
    for(i=1;i<=n;i++){
    cout<<"Masukan data ke-"<<i<<endl;
    cout<<"Masukan Kode Obat : ";cin>>rumah[i].kode;
    cout<<"Masukan Nama Obat : ";cin>>rumah[i].obat;
    cout<<"Masukan Stok Obat : ";cin>>rumah[i].stok;
    cout<<endl;
    }
    output (rumah, n);
    cari (rumah, n);
}
/*int main(){
	Sobat b;
	b.menobat();
	return 0;
}*/