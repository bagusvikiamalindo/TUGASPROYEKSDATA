void Apotek::sortingsearch() {
  sortingobt menuA[100];
  int N = 100;
  int harga_temp;
  string namamen, Menu_temp;
  // struct sortingsearch{
  //   int menuA[100];
  //   int hrg;
  //   string Menu;
  //   int pilih, i , j, N;
  //   string namamen;
  
  menuA[0].hrg = 37000;
  menuA[0].Menu  = "Tolak angin cair Plus Madu sachet";
  menuA[1].hrg = 23000;
  menuA[1].Menu  = "Becom Zet Kaplet (10 Kalpet) ";
  menuA[2].hrg = 21200;
  menuA[2].Menu  = "Zegavit Kaplet (5 Kaplet)";
  menuA[3].hrg = 90200;
  menuA[3].Menu  = "Imbost F0orce Kaplet (10 Kaplet)";
  menuA[4].hrg = 34400;
  menuA[4].Menu  = "Enervon C tablet (1 botol dan 30 Tablet)";
  menuA[5].hrg = 112716;
  menuA[5].Menu  = "Omepros kapsul (30 Kapsul)";
  menuA[6].hrg = 172000;
  menuA[6].Menu  = "Blackmores Pregnancy ";
  menuA[7].hrg = 197000;
  menuA[7].Menu  = "Blackmores Odourless";
  menuA[8].hrg = 48000;
  menuA[8].Menu  = "Lianhua Qinwen Kapsul";
  menuA[9].hrg = 64000;
  menuA[9].Menu  = "Stimuno Forte Kapsul (30 Kapsul)";
  menuA[10].hrg = 42000;
  menuA[10].Menu  = "Vitalong C Kapsul";
  menuA[11].hrg = 24000;
  menuA[11].Menu  = " Prove D3-1000 Tablet";
  menuA[12].hrg = 140000;
  menuA[12].Menu  = "Vegablend 21 Adult Kapsul";
  menuA[13].hrg = 114100;
  menuA[13].Menu  = "Oxyvit D3 60 Kapsul";
  menuA[14].hrg = 34200;
  menuA[14].Menu  = "Neurobion Forte 10 Tablet";
  menuA[15].hrg = 27600;
  menuA[15].Menu  = "Imboost Kids 21 Tablet Hisap";
  menuA[16].hrg = 28000;
  menuA[16].Menu  = "Prove D3-1000 IU 10 Tablet";
  menuA[17].hrg = 60200;
  menuA[17].Menu  = "Astria 4 mg 12 Kapsul";
  menuA[18].hrg = 34000;
  menuA[18].Menu  = "Halowell E 200 IU 12 Kapsul";
  menuA[19].hrg = 127900;
  menuA[19].Menu  = "Folamil Genio 30 Kapsul ";
  menuA[20].hrg = 24000;
  menuA[20].Menu  = "Acyclovir 1 Tablet";
  menuA[21].hrg = 30000;
  menuA[21].Menu  = "Albothyl  ";
  menuA[22].hrg = 45000;
  menuA[22].Menu  = "Alpara ";
  menuA[23].hrg = 40000;
  menuA[23].Menu  = "Ambroxol 30mg 1 tablet ";
  menuA[24].hrg = 35000;
  menuA[24].Menu  = "Amoxicillin 1 tablet ";
  menuA[25].hrg = 10000;
  menuA[25].Menu  = "Bioplacenton 1 Tube (15 gram) ";
  menuA[26].hrg = 10000;
  menuA[26].Menu  = "Calcifar Plus";
  menuA[27].hrg = 10000;
  menuA[27].Menu  = "Cataflam 25MG TAB 1 Tablet";
  menuA[28].hrg = 15000;
  menuA[28].Menu  = "Caviplex  ";
  menuA[29].hrg = 10000;
  menuA[29].Menu  = "Cefadroxil Syrup ";
  menuA[30].hrg = 24000;
  menuA[30].Menu  = "Cefixime 1 Tablet ";
  menuA[31].hrg = 30000;
  menuA[31].Menu  = "Cetaphil Moisturising Cream 200 Mg";
  menuA[32].hrg = 45000;
  menuA[32].Menu  = "Combantrin 1 Strip ";
  menuA[33].hrg = 40000;
  menuA[33].Menu  = "Counterpain salep 15 Gr";
  menuA[34].hrg = 35000;
  menuA[34].Menu  = "Cetirizine 1 botol isi 350 Tablet";
  menuA[35].hrg = 10000;
  menuA[35].Menu  = "Dextral Forte";
  menuA[36].hrg = 10000;
  menuA[36].Menu  = "Ever E 1 Strip isi 6 kapsul";
  menuA[37].hrg = 10000;
  menuA[37].Menu  = "Gentamicin Salep 5 Gram ";
  menuA[38].hrg = 15000;
  menuA[38].Menu  = "Infus RL Merk Ecosol";
  menuA[39].hrg = 10000;
  menuA[39].Menu  = "Insto 1 Botol ";
  menuA[40].hrg = 8000;
  menuA[40].Menu  = "Acyclovir 1 Tablet ";
  menuA[41].hrg = 30000;
  menuA[41].Menu  = "Albothyl";
  menuA[42].hrg =  75665;
  menuA[42].Menu  = "Alpara";
  menuA[43].hrg = 2860;
  menuA[43].Menu  = " Ambroxol 30mg 1 tablet ";
  menuA[44].hrg = 5120;
  menuA[44].Menu  = "Amoxicillin 1 tablet";
  menuA[45].hrg = 19500;
  menuA[45].Menu  = "Bioplacenton 1 Tube (15 gram)";
  menuA[46].hrg = 2102;
  menuA[46].Menu  = "Calcifar Plus";
  menuA[47].hrg =  3800;
  menuA[47].Menu  = "Cataflam 25MG TAB 1 Tablet";
  menuA[48].hrg = 4203;
  menuA[48].Menu  = "Caviplex";
  menuA[49].hrg = 12000;
  menuA[49].Menu  = "Cefadroxil Syrup";
  menuA[50].hrg = 3200;
  menuA[50].Menu  = "Cefixime 1 Tablet";
  menuA[51].hrg = 250000;
  menuA[51].Menu  = "Cetaphil Moisturising Cream 200 Mg";
  menuA[52].hrg = 14000;
  menuA[52].Menu  = "Combantrin 1 Strip ";
  menuA[53].hrg = 27000;
  menuA[53].Menu  = "Counterpain salep 15 Gr)";
  menuA[54].hrg =  43000;
  menuA[54].Menu  = "Cetirizine 1 botol isi 350 Tablet";
  menuA[55].hrg = 5255;
  menuA[55].Menu  = "Dextral Forte ";
  menuA[56].hrg = 18000;
  menuA[56].Menu  = " Ever E 1 Strip isi 6 kapsul";
  menuA[57].hrg = 3678;
  menuA[57].Menu  = "Gentamicin Salep 5 Gram ";
  menuA[58].hrg = 13000;
  menuA[58].Menu  = "Infus RL Merk Ecosol";
  menuA[59].hrg = 14000;
  menuA[59].Menu  = "Insto 1 Botol ";
  menuA[60].hrg = 79000;
  menuA[60].Menu  = "SGM eksplore 3 Plus Susu";
  menuA[61].hrg = 135000;
  menuA[61].Menu  = "Cetaipil Baby daily ";
  menuA[62].hrg = 69665;
  menuA[62].Menu  = "Transpulmin baby Balsam 2 gram";
  menuA[63].hrg =  39860;
  menuA[63].Menu  = "Bepanten Baby salep 20 gram ";
  menuA[64].hrg = 16120;
  menuA[64].Menu  = "My Baby Minyak Telon";
  menuA[65].hrg = 140500;
  menuA[65].Menu  = "Strimar nose Hygiene Baby";
  menuA[66].hrg = 120102;
  menuA[66].Menu  = "Mom Uung ASI Bosster Kapsul  ";
  menuA[67].hrg = 99800;
  menuA[67].Menu  = "Mama's Chice intensive";
  menuA[68].hrg = 34203;
  menuA[68].Menu  = "Neppi baby Wipes Parfum ";
  menuA[69].hrg = 103000;
  menuA[69].Menu  = "Lactacyd Liquid Baby skincare baby";
  menuA[70].hrg = 52200;
  menuA[70].Menu  = "Swetty Bronze Comfort NB-S ";
  menuA[71].hrg = 16000;
  menuA[71].Menu  = "Meltafer Table Kunyah ";
  menuA[72].hrg = 22000;
  menuA[72].Menu  = "Asifit Kaplet";
  menuA[73].hrg = 44000;
  menuA[73].Menu  = "Prolacta For Mother ";
  menuA[74].hrg = 62000;
  menuA[74].Menu  = "Pure Baby Shampo ";
  menuA[75].hrg = 65255;
  menuA[75].Menu  = "Sebamed Baby";
  menuA[76].hrg = 50000;
  menuA[76].Menu  = "Mamypoko Popok  L";
  menuA[77].hrg = 14678;
  menuA[77].Menu  = "Milna Baby Biscuit";
  menuA[78].hrg = 74000;
  menuA[78].Menu  = "Prenagen Momy vanilla Box ";
  menuA[79].hrg = 104000;
  menuA[79].Menu  = "Mama's Choice almond";
  menuA[80].hrg = 24000;
  menuA[80].Menu  = "SGM u12";
  menuA[81].hrg = 9600;
  menuA[81].Menu  = " Bear Brand Susu Steril 189 ml";
  menuA[82].hrg = 180000;
  menuA[82].Menu  = "ISOPRO23 500 ml (1 Pack @ 6 Botol)";
  menuA[83].hrg = 37900;
  menuA[83].Menu  = "Seblang Banyuwangi - Beras Hitam Melik";
  menuA[84].hrg = 40200;
  menuA[84].Menu  = "OCJ - Beras Merah Pecah Kulit Vakum 1kg";
  menuA[85].hrg = 16275;
  menuA[85].Menu  = "Tresno Joyo Madu TJ Murni 150 g";
  menuA[86].hrg = 76680;
  menuA[86].Menu  = "Tropicana Slim Sweetener Classic";
  menuA[87].hrg = 4287;
  menuA[87].Menu  = "Woods Lozenges Lemon ";
  menuA[88].hrg = 106000;
  menuA[88].Menu  = "Madu Uray - Raw Honey 875 g (640 mL)";
  menuA[89].hrg = 148498;
  menuA[89].Menu  = "Boost Optimum Nestle Rasa Vanila 400 g";
  menuA[90].hrg = 46900;
  menuA[90].Menu  = "Entramix Susu Rasa Vanila 185 g";
  menuA[91].hrg = 58500;
  menuA[91].Menu  = " WRP Cookies Chocolate 12 x 30 g  ";
  menuA[92].hrg = 19900;
  menuA[92].Menu  = "Fitmee - Soto 92 g";
  menuA[93].hrg = 78500;
  menuA[93].Menu  = "WRP Delichips Salt & Pepper 12 x 40 g";
  menuA[94].hrg = 13900;
  menuA[94].Menu  = "Bionic Farm - Sweetatoes Keripik Ubi";
  menuA[95].hrg = 35000;
  menuA[95].Menu  = "Francis Organic Almond Drink";
  menuA[96].hrg = 84000;
  menuA[96].Menu  = "Heavenly Blush Tummy Yogurt Bar";
  menuA[97].hrg = 95000;
  menuA[97].Menu  = " Chia-Yo Homemade Granola Chocolate";
  menuA[98].hrg = 26800;
  menuA[98].Menu  = "Tropicana Slim Korean Garlic Cookies";
  menuA[99].hrg = 32500;
  menuA[99].Menu  = "East Bali Cashews - Granola Bites";
  menuA[100].hrg = 18500;
  menuA[100].Menu  = "Ashitaki Latte 24 g (1 Box @ 5 Sachet)";
  
  for (int i=0;i<N;i++) {
    for (int j=0;j<N-1;j++) {
      if (menuA[j].hrg > menuA[j+1].hrg) {
        
        harga_temp = menuA[j].hrg;
        Menu_temp = menuA[j].Menu;
        
        menuA[j].hrg = menuA[j+1].hrg;
        menuA[j].Menu = menuA[j+1].Menu;
        
        menuA[j+1].hrg = harga_temp;
        menuA[j+1].Menu = Menu_temp;
      }
    }
  }
  cout << "ASCENDING Harga termurah sampai harga termahal" << endl;
  cout <<"HARGA                MENU   "<<endl;
  for(int i=0; i<N ; i++){
    cout << "--------------------------------------------" << endl;
    cout << menuA[i].hrg << "      " << menuA[i].Menu<< endl;
  }
    cout << "--------------------------------------------" << endl;
  
  ulangi:
cout<<"============================================= "<<endl;
cout<<"LANJUT SEARCHING"<<endl;
cout<<"1. YA"<<endl;
cout<<"2. Tidak "<<endl;
cout<<"Pilih : ";
cin>>pilih;

if(pilih == 1){
  cout << "\nMasukkan Nama obat untuk mendapatkan data Anda = ";
  cin.ignore();
  getline(cin,namamen);
  for (int i=0;i<N;i++) {
    if (menuA[i].Menu == namamen) {
      cout << "------------------------------------"<<endl;
      cout << "Menu    : " << menuA[i].Menu << endl;
      cout << "Harga   : " << menuA[i].hrg << endl;
      cout << "------------------------------------"<<endl;
      cout<<endl;
     
    }
  }
}else if(pilih == 2){
  
}else{
  cout<<"PILIHAN SALAH"<<endl;
  goto ulangi;
}
}