#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string.h>
#include <fstream>

using namespace std;

struct DataPohon{
	string namapas, namapoli, namadokter, diagnosa; 
  int nik;
  DataPohon *kirii;      
	DataPohon *kanann;     
};
DataPohon *baruu, *phn;

class icu{
  public:
    void tambahPohon(DataPohon **akar, int nik, string namapas, string namapoli, string namadokter, string diagnosa);
    void lihatpreorderPohon(DataPohon *akar);
    void lihatinorderPohon(DataPohon *akar);
    void lihatpostorderPohon(DataPohon *akar);
    void preorderPohon(DataPohon *akar);
    void inorderPohon(DataPohon *akar);
    void postorderPohon(DataPohon *akar);
    void statusPohon(DataPohon *akar);
    void menu();
  
  private:
    string namapas, namapoli, namadokter, diagnosa;
    int nik;
};

void icu::tambahPohon(DataPohon **akar, int nik, string namapas, string namapoli, string namadokter, string diagnosa){
	baruu = new DataPohon; 
	if((*akar) == NULL){   		                                      
    baruu->nik = nik;   
  	baruu->namapas = namapas;
    baruu->namapoli = namapoli;   
  	baruu->namadokter = namadokter;
    baruu->diagnosa = diagnosa;
  	baruu->kirii = NULL;       
  	baruu->kanann = NULL;  
  	(*akar) = baruu;         
  	(*akar)->kirii = NULL;         
  	(*akar)->kanann = NULL;
	}
  else if(nik < (*akar)->nik){
   	icu::tambahPohon(&(*akar)->kirii, nik, namapas, namapoli, namadokter, diagnosa);	
	} 
  else if(nik > (*akar)->nik){
   	icu::tambahPohon(&(*akar)->kanann, nik, namapas, namapoli, namadokter, diagnosa);
	}   
	else if(nik == (*akar)->nik){
		cout << endl << " Item Sudah Ada" << endl;
	} 
}

void icu::lihatpreorderPohon(DataPohon *akar){
	if(akar != NULL){
		cout << endl;
		cout << " NIK Pasien  : " << akar->nik << endl;
		cout << " Nama Pasien : " << akar->namapas << endl;        
   	icu::lihatpreorderPohon(akar->kirii),            
   	icu::lihatpreorderPohon(akar->kanann);           
  } 
  else return;
}

void icu::lihatinorderPohon(DataPohon *akar){
	if(akar != NULL){
   	icu::lihatinorderPohon(akar->kirii),
		cout << endl;         
   	cout << " NIK Pasien  : " << akar->nik << endl;
		cout << " Nama Pasien : " << akar->namapas << endl;        
		icu::lihatinorderPohon(akar->kanann);        
  } 
  else return;
} 

void icu::lihatpostorderPohon(DataPohon *akar){
	if(akar != NULL){
   	icu::lihatpostorderPohon(akar->kirii),       
   	icu::lihatpostorderPohon(akar->kanann);
		cout << endl;      
		cout << " NIK Pasien  : " << akar->nik << endl;
		cout << " Nama Pasien : " << akar->namapas << endl;      
  } 
  else return;
}

void icu::preorderPohon(DataPohon *akar){
	if(akar != NULL){
		cout << endl;
    cout << "==============================================================" << endl;
	  cout << "                       DATA PASIEN ICU" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Pasien      : " << akar->nik << endl;
    cout << " Nama Pasien     : " << akar->namapas << endl;
    cout << " Poli            : " << akar->namapoli << endl;
    cout << " Nama Dokter     : " << akar->namadokter << endl;
    cout << " Diagnosa        : " << akar->diagnosa << endl;
	  cout << "==============================================================" << endl; 

    ofstream doks("datapasienicu.txt", ios::app);
    
    doks << "==============================================================" << endl;
	  doks << "                    DATA PASIEN ICU" << endl;
	  doks << "--------------------------------------------------------------" << endl;
    doks << " NIK Pasien      : " << akar->nik << endl;
    doks << " Nama Pasien     : " << akar->namapas << endl;
    doks << " Poli            : " << akar->namapoli << endl;
    doks << " Nama Dokter     : " << akar->namadokter << endl;
    doks << " Diagnosa        : " << akar->diagnosa << endl;
	  doks << "==============================================================" << endl;
	  doks << endl;
   	icu::preorderPohon(akar->kirii),            
   	icu::preorderPohon(akar->kanann);           
  } 
  else return;
}

void icu::inorderPohon(DataPohon *akar){
	if(akar != NULL){
   	icu::inorderPohon(akar->kirii),
		cout << endl;
    cout << "==============================================================" << endl;
	  cout << "                       DATA PASIEN ICU" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Pasien      : " << akar->nik << endl;
    cout << " Nama Pasien     : " << akar->namapas << endl;
    cout << " Poli            : " << akar->namapoli << endl;
    cout << " Nama Dokter     : " << akar->namadokter << endl;
    cout << " Diagnosa        : " << akar->diagnosa << endl;
	  cout << "==============================================================" << endl;

    ofstream doks("datapasienicu.txt", ios::app);
    
    doks << "==============================================================" << endl;
	  doks << "                    DATA PASIEN ICU" << endl;
	  doks << "--------------------------------------------------------------" << endl;
    doks << " NIK Pasien      : " << akar->nik << endl;
    doks << " Nama Pasien     : " << akar->namapas << endl;
    doks << " Poli            : " << akar->namapoli << endl;
    doks << " Nama Dokter     : " << akar->namadokter << endl;
    doks << " Diagnosa        : " << akar->diagnosa << endl;
	  doks << "==============================================================" << endl;
	  doks << endl;
	  doks << endl;
		icu::inorderPohon(akar->kanann);        
  } 
  else return;
} 

void icu::postorderPohon(DataPohon *akar){
	if(akar != NULL){
   	icu::postorderPohon(akar->kirii),       
   	icu::postorderPohon(akar->kanann);
		cout << endl;
    cout << "==============================================================" << endl;
	  cout << "                       DATA PASIEN ICU" << endl;
	  cout << "--------------------------------------------------------------" << endl;
    cout << " NIK Pasien      : " << akar->nik << endl;
    cout << " Nama Pasien     : " << akar->namapas << endl;
    cout << " Poli            : " << akar->namapoli << endl;
    cout << " Nama Dokter     : " << akar->namadokter << endl;
    cout << " Diagnosa        : " << akar->diagnosa << endl;
	  cout << "==============================================================" << endl;     

    ofstream doks("datapasienicu.txt", ios::app);
    
    doks << "==============================================================" << endl;
	  doks << "                    DATA PASIEN ICU" << endl;
	  doks << "--------------------------------------------------------------" << endl;
    doks << " NIK Pasien      : " << akar->nik << endl;
    doks << " Nama Pasien     : " << akar->namapas << endl;
    doks << " Poli            : " << akar->namapoli << endl;
    doks << " Nama Dokter     : " << akar->namadokter << endl;
    doks << " Diagnosa        : " << akar->diagnosa << endl;
	  doks << "==============================================================" << endl;
	  doks << endl;
    
  } 
  else return;
}

void icu::statusPohon(DataPohon *akar){
	if(akar != NULL){
   	cout << endl;
		cout << "--------------------- DATA PASIEN TELAH DIINPUTKAN --------------------" << endl;
  } 
  else {
    cout << endl;
		cout << " Data Pohon Kosong " << endl;
  }
}

void icu::menu(){
  int k;
do { 
  cout<<"1. Tambah data "<<endl;
  cout<<"2. Lihat preorder "<<endl;
  cout<<"3. Lihat inorder "<<endl;
  cout<<"4. Lihat postorder "<<endl;
  cout<<"5. Cetak secara preorder "<<endl;
  cout<<"6. Cetak secara inorder "<<endl;
  cout<<"7. Cetak secara postorder "<<endl;
  cout<<"Masukkan : ";
  cin>>k;
  switch (k){
    case 1 :
    cout << " NIK Pasien      : ";
    cin >> nik;
    cout << " Nama Pasien     : ";
    cin >> namapas;
    cout << " Poli            : ";
    cin >> namapoli;
    cout << " Nama Dokter     : "; 
    cin >> namadokter;
    cout << " Diagnosa        : "; 
    cin >> diagnosa;
    tambahPohon(&phn, nik, namapas, namapoli, namadokter, diagnosa);
    break;
    case 2 :
  lihatpreorderPohon(phn);
    break;
    case 3 :
  lihatinorderPohon(phn);
    break;
    case 4 :
  lihatpostorderPohon(phn);
    break;
    case 5 :
  preorderPohon(phn);
    break;
    case 6 :
  inorderPohon(phn);
    break;
    case 7 :
  postorderPohon(phn);
    break;
    }
  } while (k < 5);
}